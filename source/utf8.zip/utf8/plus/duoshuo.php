<?php
if (!extension_loaded('json'))
	include_once DEDEROOT.'/plus/duoshuo/compat_json.php';

require DEDEROOT.'/plus/duoshuo/Exception.php';
require DEDEROOT.'/plus/duoshuo/Client.php';
require DEDEROOT.'/plus/duoshuo/Abstract.php';
require DEDEROOT.'/plus/duoshuo/Dedecms.php';